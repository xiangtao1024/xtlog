# xtlog-client · Windows (x64)

xtlog 的客户端采集推送器：放在**被采集的 Windows 机器**上，按配置采集本机日志并 HTTP 推送到 xtlog-server。

本目录已附带编译好的 `xtlog-client.exe`（Windows x64，含最新日志解析规则：Java / nginx / syslog / MySQL 慢查询等）。

## 快速使用

```bat
rem 1) 复制配置模板并改成自己的
copy config.example.json config.json
rem 编辑 config.json：server 填 xtlog 服务地址，token 填应用管理页生成的接入 Token

rem 2) 启动（前台，Ctrl+C 结束）
xtlog-client.exe --config=config.json

rem 3) 查看版本 / 帮助
xtlog-client.exe --version
xtlog-client.exe --help
```

- CLI 参数：`--config=config.json`、`--config config.json`、`-c config.json`；不带参数默认读当前目录 `config.json`。
- `config.json` 里 `type=cmd` 的 `shell` 在 Windows 上默认用 `cmd.exe /c`；`type=file` 的 `encoding` 中文程序可填 `gbk`。
- `stateFile`（文件采集偏移落盘）按**启动时的当前工作目录**解析，建议用绝对路径避免找不到。

## 常驻运行

前台窗口不便长期运行时，可用计划任务或 `nssm` 把 exe 包成 Windows 服务，例如：

```bat
nssm install xtlog-client "%~dp0xtlog-client.exe" --config=%~dp0config.json
nssm start xtlog-client
```

## 配置文件

字段完整说明见项目根目录 `client/README.md`：顶层 `server / srcIp / batchSize / flushIntervalMs / retry / queueMax / stateFile`，采集器 `collectors[]`（`token` / `appId` / `type` / `paths` 或 `command`）。

> 只支持 `http://` 上报。服务端要走 https 时，在前面挂 nginx 做 TLS 终结，客户端填 `http://127.0.0.1:18080`。
