# xtlog-client · Debian / Ubuntu (Linux)

xtlog 的客户端采集推送器：放在**被采集的 Linux 机器**上，按配置采集本机日志并 HTTP 推送到 xtlog-server。

> **本包不包含二进制文件**——请在目标机器上自行构建后把 `xtlog-client` 放进本目录（见下方「构建二进制」）。
> 之所以不带二进制：Linux 发行版 / 架构（x86_64、ARM64）差异大，且 Windows 上无法交叉编译出可用的 ELF 文件，
> 在目标机上原地构建最可靠。

## 目录内容

| 文件 | 说明 |
| --- | --- |
| `config.example.json` | 配置模板（Linux 路径风格，含 file / cmd 两种采集器示例） |
| `xtlog-client.service` | systemd 服务文件（假设安装到 `/opt/xtlog-client`） |
| `build.sh` | 在目标机上构建二进制的脚本 |
| `README.md` | 本说明 |

## 1. 构建二进制（二进制由你自行放入）

把整个 `xtlog-client-0.1.0` 解压到目标机器后，在 `debian/` 目录里：

```bash
cd /opt/xtlog-client              # 假设解压到这里
sudo apt update && sudo apt install -y curl build-essential
curl https://sh.rustup.rs | sh -s -- -y
source $HOME/.cargo/env

# 构建当前平台（产物 target/release/xtlog-client）
./build.sh
# 或指定架构：./build.sh linux-x64  /  ./build.sh linux-arm64

# 把二进制放到 service 文件期望的位置
cp target/release/xtlog-client /opt/xtlog-client/xtlog-client
chmod +x /opt/xtlog-client/xtlog-client
```

只需要 Rust 工具链，编出来的是单一可执行文件，目标机无需运行时依赖。

## 2. 配置

```bash
cp config.example.json config.json
vi config.json
```

- `server`：填 xtlog 服务地址，如 `http://192.168.1.10:18080`（结尾不要带 `/`，只支持 http）。
- `srcIp`：留空自动探测；多网卡判断不准就写死本机 IP。
- `collectors[]`：每个元素对应 xtlog 里的一个应用，`token` 填应用管理页生成的接入 Token。
  - `type=file`：`paths` 填日志文件路径，中文日志 `encoding` 可填 `gbk`，`fromStart` 控制是否补历史。
  - `type=cmd`：`command` 填常驻命令，如 `journalctl -u game.service -f -o short-iso`、`tail -F /var/log/app.log`。
- `stateFile`：文件采集偏移落盘，建议保留（相对路径按工作目录解析，service 里已设 `WorkingDirectory=/opt/xtlog-client`）。

## 3. systemd 常驻（推荐）

service 文件按安装到 `/opt/xtlog-client` 写好了。若换目录，改 `WorkingDirectory` 和 `ExecStart`：

```bash
sudo cp xtlog-client.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now xtlog-client
sudo systemctl status xtlog-client
sudo journalctl -u xtlog-client -f
```

不用 systemd 也可直接前台运行：`./xtlog-client --config=config.json`（`Ctrl+C` 或 `SIGTERM` 优雅退出）。

## 配置文件字段说明

见项目根目录 `client/README.md`：顶层 `server / srcIp / batchSize / flushIntervalMs / retry / queueMax / stateFile`，
采集器 `collectors[]`（`token` / `appId` / `type` / `paths` 或 `command` / `encoding` / `fromStart` / `shell`）。

> 只支持 `http://` 上报。服务端要走 https 时，挂 nginx 做 TLS 终结，客户端填 `http://127.0.0.1:18080`。
